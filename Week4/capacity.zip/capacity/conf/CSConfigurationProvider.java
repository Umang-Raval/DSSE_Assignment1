/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.yarn.server.resourcemanager.scheduler.capacity.conf;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.yarn.server.resourcemanager.scheduler.capacity.CapacityScheduler;
import org.apache.hadoop.yarn.server.resourcemanager.scheduler.capacity.CapacitySchedulerConfiguration;

import java.io.IOException;

/**
 * Configuration provider for {@link CapacityScheduler}.
 */
public interface CSConfigurationProvider {

  /**
   * Initialize the configuration provider with given conf.
   * @param conf configuration to initialize with
   * @throws IOException if initialization fails due to misconfiguration
   */
  void init(Configuration conf) throws IOException;

  /**
   * Loads capacity scheduler configuration object.
   * @param conf initial bootstrap configuration
   * @return CS configuration
   * @throws IOException if fail to retrieve configuration
   */
  CapacitySchedulerConfiguration loadConfiguration(Configuration conf)
      throws IOException;
}
